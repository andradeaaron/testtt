package backend;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class Servidor {

    private static final ProductoDAO prodDAO = new ProductoDAO();
    private static final UsuarioDAO userDAO = new UsuarioDAO();
    private static final SolicitudDAO solDAO = new SolicitudDAO();
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void main(String[] args) throws IOException {
        System.out.println("🔄 Iniciando componentes del servidor...");
        try {
            prodDAO.crearTabla();
            userDAO.crearTabla();
            solDAO.crearTabla();
            System.out.println("✅ Tablas verificadas/creadas con éxito.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        String portEnv = System.getenv("PORT");
        int puerto = (portEnv != null) ? Integer.parseInt(portEnv) : 8080;

        HttpServer server = HttpServer.create(new InetSocketAddress(puerto), 0);

        server.createContext("/", new FrontendHandler());
        server.createContext("/api/productos", new ProductosHandler());
        server.createContext("/api/usuarios", new UsuariosHandler());
        server.createContext("/api/solicitudes", new SolicitudesHandler());
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/calificar", new CalificarHandler());

        server.setExecutor(null);
        System.out.println("🚀 Servidor HTTP corriendo en el puerto: " + puerto);
        server.start();
    }

    // ─── PÁGINA PRINCIPAL → sirve index.html ───
    static class FrontendHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1); return;
            }
            // Redirige a la API info si no hay frontend embebido
            String html = "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>"
                + "<title>Plataforma API</title></head><body>"
                + "<h1>✅ Servidor corriendo</h1>"
                + "<p>Endpoints disponibles:</p><ul>"
                + "<li>POST /api/login</li>"
                + "<li>GET/POST /api/usuarios</li>"
                + "<li>GET/POST/PUT/DELETE/PATCH /api/productos</li>"
                + "<li>GET/POST/PATCH /api/solicitudes</li>"
                + "<li>POST /api/calificar</li>"
                + "</ul></body></html>";
            enviarRespuestaHTML(exchange, 200, html);
        }
    }

    // ─── LOGIN (nuevo endpoint) ───
    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1); return;
            }
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                enviarRespuesta(exchange, 405, "{\"error\":\"Método no soportado\"}"); return;
            }
            try {
                @SuppressWarnings("unchecked")
                Map<String, String> body = mapper.readValue(exchange.getRequestBody(), Map.class);
                String email = body.get("email");
                String password = body.get("password");
                Usuario u = userDAO.login(email, password);
                if (u != null) {
                    // No enviar password al cliente
                    u.setPassword(null);
                    enviarRespuesta(exchange, 200, mapper.writeValueAsString(u));
                } else {
                    enviarRespuesta(exchange, 401, "{\"error\":\"Credenciales incorrectas\"}");
                }
            } catch (Exception e) {
                enviarRespuesta(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // ─── CALIFICAR PRODUCTO ───
    static class CalificarHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1); return;
            }
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                enviarRespuesta(exchange, 405, "{\"error\":\"Método no soportado\"}"); return;
            }
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> body = mapper.readValue(exchange.getRequestBody(), Map.class);
                int productoId = (Integer) body.get("productoId");
                double calificacion = ((Number) body.get("calificacion")).doubleValue();
                if (calificacion < 1 || calificacion > 5) {
                    enviarRespuesta(exchange, 400, "{\"error\":\"La calificación debe ser entre 1 y 5\"}"); return;
                }
                boolean ok = prodDAO.calificar(productoId, calificacion);
                enviarRespuesta(exchange, ok ? 200 : 400, "{\"success\":" + ok + "}");
            } catch (Exception e) {
                enviarRespuesta(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // ─── HANDLER PRODUCTOS ───
    static class ProductosHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            String metodo = exchange.getRequestMethod();
            String query = exchange.getRequestURI().getQuery();

            if ("OPTIONS".equalsIgnoreCase(metodo)) {
                exchange.sendResponseHeaders(204, -1); return;
            }

            try {
                if ("GET".equalsIgnoreCase(metodo)) {
                    List<Producto> lista;
                    if (query != null && query.contains("estado=PENDIENTE")) {
                        lista = prodDAO.listarPendientes();
                    } else if (query != null && query.contains("ofertanteId=")) {
                        int id = Integer.parseInt(query.split("ofertanteId=")[1].split("&")[0]);
                        lista = prodDAO.listarPorOfertante(id);
                    } else if (query != null && query.contains("orden=")) {
                        String orden = query.split("orden=")[1].split("&")[0];
                        lista = prodDAO.listarAprobadosConFiltro(orden);
                    } else if (query != null && query.contains("id=")) {
                        int id = Integer.parseInt(query.split("id=")[1].split("&")[0]);
                        Producto p = prodDAO.buscarPorId(id);
                        if (p == null) { enviarTextoPlano(exchange, 200, "No hay productos con ese ID"); return; }
                        enviarRespuesta(exchange, 200, mapper.writeValueAsString(p)); return;
                    } else {
                        lista = prodDAO.listarAprobadosConFiltro("recientes");
                    }
                    if (lista == null || lista.isEmpty()) enviarTextoPlano(exchange, 200, "No hay productos registrados");
                    else enviarRespuesta(exchange, 200, mapper.writeValueAsString(lista));

                } else if ("POST".equalsIgnoreCase(metodo)) {
                    Producto p = mapper.readValue(exchange.getRequestBody(), Producto.class);
                    p.setEstado("PENDIENTE");
                    boolean ok = prodDAO.registrar(p);
                    enviarRespuesta(exchange, ok ? 201 : 400, "{\"success\":" + ok + "}");

                } else if ("PUT".equalsIgnoreCase(metodo)) {
                    Producto p = mapper.readValue(exchange.getRequestBody(), Producto.class);
                    if (p.getId() <= 0) { enviarRespuesta(exchange, 400, "{\"error\":\"ID obligatorio\"}"); return; }
                    boolean ok = prodDAO.actualizar(p);
                    enviarRespuesta(exchange, ok ? 200 : 400, "{\"success\":" + ok + "}");

                } else if ("DELETE".equalsIgnoreCase(metodo)) {
                    if (query != null && query.contains("id=")) {
                        int id = Integer.parseInt(query.split("id=")[1].split("&")[0]);
                        boolean ok = prodDAO.eliminar(id);
                        enviarRespuesta(exchange, ok ? 200 : 400, "{\"success\":" + ok + "}");
                    } else { enviarRespuesta(exchange, 400, "{\"error\":\"Falta ID\"}"); }

                } else if ("PATCH".equalsIgnoreCase(metodo)) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> body = mapper.readValue(exchange.getRequestBody(), Map.class);
                    int id = (Integer) body.get("id");
                    String decision = (String) body.get("decision");
                    String motivo = (String) body.get("motivoRechazo");
                    if ("RECHAZADO".equals(decision) && (motivo == null || motivo.trim().isEmpty())) {
                        enviarRespuesta(exchange, 400, "{\"error\":\"Motivo de rechazo obligatorio\"}"); return;
                    }
                    boolean ok = prodDAO.validar(id, decision, motivo);
                    enviarRespuesta(exchange, ok ? 200 : 400, "{\"success\":" + ok + "}");
                }
            } catch (Exception e) {
                e.printStackTrace();
                enviarRespuesta(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // ─── HANDLER SOLICITUDES ───
    static class SolicitudesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            String metodo = exchange.getRequestMethod();
            String query = exchange.getRequestURI().getQuery();

            if ("OPTIONS".equalsIgnoreCase(metodo)) {
                exchange.sendResponseHeaders(204, -1); return;
            }

            try {
                if ("POST".equalsIgnoreCase(metodo)) {
                    Solicitud s = mapper.readValue(exchange.getRequestBody(), Solicitud.class);
                    s.setEstado("PENDIENTE");
                    boolean ok = solDAO.registrar(s);
                    enviarRespuesta(exchange, ok ? 201 : 400, "{\"success\":" + ok + "}");

                } else if ("GET".equalsIgnoreCase(metodo)) {
                    if (query != null && query.contains("ofertanteId=")) {
                        int ofertanteId = Integer.parseInt(query.split("ofertanteId=")[1].split("&")[0]);
                        List<Solicitud> lista = solDAO.listarPorOfertante(ofertanteId);
                        if (lista == null || lista.isEmpty()) enviarTextoPlano(exchange, 200, "No hay solicitudes");
                        else enviarRespuesta(exchange, 200, mapper.writeValueAsString(lista));
                    } else if (query != null && query.contains("demandanteId=")) {
                        int demandanteId = Integer.parseInt(query.split("demandanteId=")[1].split("&")[0]);
                        List<Solicitud> lista = solDAO.listarPorDemandante(demandanteId);
                        if (lista == null || lista.isEmpty()) enviarTextoPlano(exchange, 200, "No hay solicitudes");
                        else enviarRespuesta(exchange, 200, mapper.writeValueAsString(lista));
                    } else {
                        enviarRespuesta(exchange, 400, "{\"error\":\"Se requiere ofertanteId o demandanteId\"}");
                    }

                } else if ("PATCH".equalsIgnoreCase(metodo)) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> body = mapper.readValue(exchange.getRequestBody(), Map.class);
                    int id = (Integer) body.get("id");
                    String nuevoEstado = (String) body.get("estado");
                    if (!"ACEPTADA".equals(nuevoEstado) && !"RECHAZADA".equals(nuevoEstado)) {
                        enviarRespuesta(exchange, 400, "{\"error\":\"Estado no válido. Use ACEPTADA o RECHAZADA\"}"); return;
                    }
                    boolean ok = solDAO.responder(id, nuevoEstado);
                    enviarRespuesta(exchange, ok ? 200 : 400, "{\"success\":" + ok + "}");
                } else {
                    enviarRespuesta(exchange, 405, "{\"error\":\"Método no soportado\"}");
                }
            } catch (Exception e) {
                e.printStackTrace();
                enviarRespuesta(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // ─── HANDLER USUARIOS ───
    static class UsuariosHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            configurarCORS(exchange);
            String metodo = exchange.getRequestMethod();

            if ("OPTIONS".equalsIgnoreCase(metodo)) {
                exchange.sendResponseHeaders(204, -1); return;
            }

            try {
                if ("GET".equalsIgnoreCase(metodo)) {
                    List<Usuario> lista = userDAO.listar();
                    // No enviar passwords
                    lista.forEach(u -> u.setPassword(null));
                    if (lista == null || lista.isEmpty()) enviarTextoPlano(exchange, 200, "No hay usuarios registrados");
                    else enviarRespuesta(exchange, 200, mapper.writeValueAsString(lista));

                } else if ("POST".equalsIgnoreCase(metodo)) {
                    Usuario u = mapper.readValue(exchange.getRequestBody(), Usuario.class);
                    boolean ok = userDAO.registrar(u);
                    enviarRespuesta(exchange, ok ? 201 : 400, "{\"success\":" + ok + "}");

                } else if ("DELETE".equalsIgnoreCase(metodo)) {
                    String query = exchange.getRequestURI().getQuery();
                    if (query != null && query.contains("id=")) {
                        int id = Integer.parseInt(query.split("id=")[1].split("&")[0]);
                        boolean ok = userDAO.eliminar(id);
                        enviarRespuesta(exchange, ok ? 200 : 400, "{\"mensaje\":\"" + (ok ? "Usuario eliminado" : "No se pudo eliminar") + "\"}");
                    } else { enviarRespuesta(exchange, 400, "{\"mensaje\":\"Falta ID\"}"); }
                }
            } catch (Exception e) {
                enviarRespuesta(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // ─── HELPERS ───
    private static void configurarCORS(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private static void enviarRespuesta(HttpExchange exchange, int codigo, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(codigo, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }

    private static void enviarRespuestaHTML(HttpExchange exchange, int codigo, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(codigo, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }

    private static void enviarTextoPlano(HttpExchange exchange, int codigo, String texto) throws IOException {
        byte[] bytes = texto.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
        exchange.sendResponseHeaders(codigo, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }
}

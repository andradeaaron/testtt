package backend;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS usuarios ("
                   + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                   + "nombre TEXT NOT NULL, "
                   + "email TEXT UNIQUE NOT NULL, "
                   + "password TEXT NOT NULL, "
                   + "rol TEXT NOT NULL DEFAULT 'DEMANDANTE'"
                   + ");";
        try (Connection con = Conexion.conectar();
             java.sql.Statement stmt = con.createStatement()) {
            stmt.execute(sql);
            // Migración: agregar columna rol si no existe (base de datos vieja)
            try { stmt.execute("ALTER TABLE usuarios ADD COLUMN rol TEXT NOT NULL DEFAULT 'DEMANDANTE'"); }
            catch (SQLException ignored) {} // Ya existe, ignorar
            // Insertar usuarios demo si la tabla está vacía
            insertarDemoSiVacio(con);
            System.out.println("Tabla 'usuarios' verificada/creada en SQLite.");
        } catch (SQLException e) {
            System.out.println("Error al crear tabla usuarios: " + e.getMessage());
        }
    }

    private void insertarDemoSiVacio(Connection con) throws SQLException {
        String checkSql = "SELECT COUNT(*) FROM usuarios";
        try (PreparedStatement ps = con.prepareStatement(checkSql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next() && rs.getInt(1) == 0) {
                String insertSql = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ins = con.prepareStatement(insertSql)) {
                    // Admin demo
                    ins.setString(1, "Admin Sistema"); ins.setString(2, "admin@test.com");
                    ins.setString(3, "admin123"); ins.setString(4, "ADMINISTRADOR");
                    ins.executeUpdate();
                    // Ofertante demo
                    ins.setString(1, "Juan Ofertante"); ins.setString(2, "juan@test.com");
                    ins.setString(3, "123456"); ins.setString(4, "OFERTANTE");
                    ins.executeUpdate();
                    // Demandante demo
                    ins.setString(1, "Maria Compradora"); ins.setString(2, "maria@test.com");
                    ins.setString(3, "123456"); ins.setString(4, "DEMANDANTE");
                    ins.executeUpdate();
                }
                System.out.println("Usuarios demo insertados.");
            }
        }
    }

    public boolean registrar(Usuario usuario) {
        String sql = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol() != null ? usuario.getRol() : "DEMANDANTE");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al registrar: " + e.getMessage());
            return false;
        }
    }

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar: " + e.getMessage());
        }
        return lista;
    }

    public boolean actualizar(Usuario usuario) {
        String sql = "UPDATE usuarios SET nombre=?, email=?, password=?, rol=? WHERE id=?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol());
            ps.setInt(5, usuario.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE id=?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }

    public Usuario login(String email, String password) {
        String sql = "SELECT * FROM usuarios WHERE email=? AND password=?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        } catch (SQLException e) {
            System.out.println("Error en login: " + e.getMessage());
        }
        return null;
    }

    private Usuario mapear(ResultSet rs) throws SQLException {
        String rol = "DEMANDANTE";
        try { rol = rs.getString("rol"); } catch (SQLException ignored) {}
        return new Usuario(
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getString("email"),
            rs.getString("password"),
            rol
        );
    }
}

// ── Configuración ───────────────────────────────────────────────────────
const API = 'http://localhost:8080/api';
let usuarioActual = null;

// ── Inicialización ────────────────────────────────────────────────────────
function checkAuth() {
    const guardado = sessionStorage.getItem('userSession');
    if (guardado) {
        usuarioActual = JSON.parse(guardado);
        mostrarApp();
    } else {
        mostrarLogin();
    }
}

function mostrarLogin() {
    ocultarTodas();
    document.getElementById('loginSection').classList.add('active');
    document.getElementById('navbar').style.display = 'none';
}

function mostrarApp() {
    ocultarTodas();
    document.getElementById('navbar').style.display = 'flex';
    document.getElementById('navNombre').textContent = usuarioActual.nombre;

    const badge = document.getElementById('navRolBadge');
    const rolMap = { ADMINISTRADOR: ['rol-admin', 'Admin'], OFERTANTE: ['rol-ofertante', 'Ofertante'], DEMANDANTE: ['rol-demandante', 'Demandante'] };
    const [cls, label] = rolMap[usuarioActual.rol] || ['rol-demandante', usuarioActual.rol];
    badge.className = 'nav-rol ' + cls;
    badge.textContent = label;

    // Redirección por rol
    if (usuarioActual.rol === 'ADMINISTRADOR') {
        document.getElementById('appAdmin').classList.add('active');
        cargarUsuarios();
    } else if (usuarioActual.rol === 'OFERTANTE') {
        document.getElementById('appOfertante').classList.add('active');
        cargarMisProductos();
    } else {
        document.getElementById('appDemandante').classList.add('active');
        cargarCatalogo();
    }
}

function ocultarTodas() {
    ['loginSection','appAdmin','appOfertante','appDemandante'].forEach(id => {
        document.getElementById(id).classList.remove('active');
    });
}

// ── LOGIN ─────────────────────────────────────────────────────────────────
async function hacerLogin() {
    const email    = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl    = document.getElementById('loginError');

    try {
        const res = await fetch(API + '/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        if (res.ok) {
            usuarioActual = await res.json();
            sessionStorage.setItem('userSession', JSON.stringify(usuarioActual));
            errEl.style.display = 'none';
            mostrarApp();
        } else {
            errEl.style.display = 'block';
        }
    } catch (e) {
        errEl.textContent = '❌ No se pudo conectar al servidor. ¿Está corriendo en el puerto 8080?';
        errEl.style.display = 'block';
    }
}

// Soporte Enter en el formulario de login
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && document.getElementById('loginSection').classList.contains('active')) {
        if (document.getElementById('loginFormContainer').style.display !== 'none') hacerLogin();
    }
});

// ── REGISTRO ──────────────────────────────────────────────────────────────
window.registrarUsuario = async function() {
    const nombre   = document.getElementById('regNombre').value.trim();
    const email    = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const rol      = document.getElementById('regRol').value;

    if (!nombre || !email || !password) return alert('❌ Todos los campos son obligatorios.');
    if (password.length < 6) return alert('❌ La contraseña debe tener al menos 6 caracteres.');

    try {
        const res = await fetch(API + '/usuarios', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email, password, rol })
        });
        const data = await res.json();
        if (data.success) {
            mostrarMsg('msgRegistro', '✅ ¡Cuenta creada! Ahora inicia sesión.', 'ok');
            setTimeout(() => conmutarAuth(false), 1500);
        } else {
            mostrarMsg('msgRegistro', '❌ No se pudo registrar. ¿El email ya existe?', 'err');
        }
    } catch (e) {
        mostrarMsg('msgRegistro', '❌ Error de conexión con el servidor.', 'err');
    }
};

// ── LOGOUT ────────────────────────────────────────────────────────────────
function logout() {
    sessionStorage.removeItem('userSession');
    usuarioActual = null;
    mostrarLogin();
}

// ── TABS ─────────────────────────────────────────────────────────────────
function switchTab(nombre, btn) {
    // Encontrar el panel padre del botón y trabajar dentro de él
    const panel = btn.closest('.section');
    panel.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    panel.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + nombre).classList.add('active');
    btn.classList.add('active');

    // Lazy load por tab
    const loaders = {
        'adminUsuarios':   cargarUsuarios,
        'adminProductos':  cargarAdmin,
        'adminCatalogo':   () => cargarCatalogoEn('catalogoAdmin'),
        'ofertMisProds':   cargarMisProductos,
        'ofertSolicitudes': cargarSolicitudesOfertante,
        'demCatalogo':     cargarCatalogo,
        'demMisSolicitudes': cargarMisSolicitudes,
    };
    if (loaders[nombre]) loaders[nombre]();
}

// ── PANEL ADMIN: USUARIOS ─────────────────────────────────────────────────
async function cargarUsuarios() {
    try {
        const res = await fetch(API + '/usuarios');
        if (!res.ok) { document.getElementById('usersTableBody').innerHTML = '<tr><td colspan="5">Error al cargar</td></tr>'; return; }
        const data = await res.text();
        let users;
        try { users = JSON.parse(data); } catch { users = []; }

        const tbody = document.getElementById('usersTableBody');
        if (!tbody) return;
        tbody.innerHTML = users.map(u => `
            <tr>
                <td>${u.id}</td>
                <td>${u.nombre}</td>
                <td>${u.email}</td>
                <td><span class="badge ${u.rol === 'ADMINISTRADOR' ? 'b-rejected' : u.rol === 'OFERTANTE' ? 'b-info' : 'b-approved'}">${u.rol || '–'}</span></td>
                <td><button class="btn-danger btn-sm" onclick="eliminarUsuario(${u.id})">Eliminar</button></td>
            </tr>`).join('');
    } catch (e) { console.error('Error cargar usuarios:', e); }
}

window.crearUsuarioAdmin = async function() {
    const nombre   = document.getElementById('adNombre').value.trim();
    const email    = document.getElementById('adEmail').value.trim();
    const password = document.getElementById('adPassword').value;
    const rol      = document.getElementById('adRol').value;

    if (!nombre || !email || !password) return mostrarMsg('msgUsuario', '❌ Todos los campos son obligatorios', 'err');

    try {
        const res = await fetch(API + '/usuarios', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email, password, rol })
        });
        const data = await res.json();
        if (data.success) {
            mostrarMsg('msgUsuario', '✅ Usuario creado correctamente', 'ok');
            ['adNombre','adEmail','adPassword'].forEach(id => document.getElementById(id).value = '');
            cargarUsuarios();
        } else {
            mostrarMsg('msgUsuario', '❌ No se pudo crear. ¿Email duplicado?', 'err');
        }
    } catch (e) { mostrarMsg('msgUsuario', '❌ Error de conexión', 'err'); }
};

window.eliminarUsuario = async function(id) {
    if (!confirm('¿Eliminar este usuario?')) return;
    try {
        const res = await fetch(API + '/usuarios?id=' + id, { method: 'DELETE' });
        const data = await res.json();
        mostrarMsg('msgUsuario', '✅ ' + data.mensaje, 'ok');
        cargarUsuarios();
    } catch (e) { mostrarMsg('msgUsuario', '❌ Error al eliminar', 'err'); }
};

// ── UTILIDADES ────────────────────────────────────────────────────────────
function mostrarMsg(elId, texto, tipo) {
    const el = document.getElementById(elId);
    if (!el) return;
    el.textContent = texto;
    el.className = 'msg ' + tipo;
    el.style.display = 'block';
    setTimeout(() => el.style.display = 'none', 4000);
}

window.conmutarAuth = function(mostrarRegistro) {
    document.getElementById('loginFormContainer').style.display  = mostrarRegistro ? 'none' : 'block';
    document.getElementById('registroFormContainer').style.display = mostrarRegistro ? 'block' : 'none';
    const errEl = document.getElementById('loginError');
    if (errEl) errEl.style.display = 'none';
};

checkAuth();

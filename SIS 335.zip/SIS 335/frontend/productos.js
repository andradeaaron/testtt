// ── productos.js – Sprint 4 (Conectado al Backend Real) ─────────────────
const API_PRODS = 'http://localhost:8080/api';
let catalogoCache = [];
let productoARechazar = null;
let productoASolicitar = null;
let productoACalificar = null;
let calificacionSeleccionada = 0;

// ════════════════════════════════════════════════════════════════════════
// OFERTANTE: Guardar producto (crear o editar)
// ════════════════════════════════════════════════════════════════════════
async function guardarProducto() {
    const editId = document.getElementById('prodEditId').value;
    const body = {
        titulo:      document.getElementById('prodTitulo').value.trim(),
        descripcion: document.getElementById('prodDesc').value.trim(),
        precio:      parseFloat(document.getElementById('prodPrecio').value),
        categoria:   document.getElementById('prodCategoria').value,
        tipo:        document.getElementById('prodTipo').value,
        ofertanteId: usuarioActual ? usuarioActual.id : 0,
        ofertanteNombre: usuarioActual ? usuarioActual.nombre : ''
    };

    if (!body.titulo || body.titulo.length < 3)
        return mostrarMsg('msgProducto', '❌ El título debe tener al menos 3 caracteres', 'err');
    if (!body.descripcion || body.descripcion.length < 10)
        return mostrarMsg('msgProducto', '❌ La descripción debe tener al menos 10 caracteres', 'err');
    if (!body.precio || body.precio <= 0)
        return mostrarMsg('msgProducto', '❌ El precio debe ser mayor a 0', 'err');
    if (!body.categoria)
        return mostrarMsg('msgProducto', '❌ Selecciona una categoría', 'err');

    try {
        let url = API_PRODS + '/productos';
        let method = 'POST';
        if (editId) { body.id = parseInt(editId); method = 'PUT'; }

        const res = await fetch(url, {
            method, headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (data.success) {
            mostrarMsg('msgProducto', editId
                ? '✅ Producto actualizado. Quedará pendiente de aprobación.'
                : '✅ Producto registrado. Pendiente de aprobación.', 'ok');
            cancelarEdicion();
            cargarMisProductos();
        } else {
            mostrarMsg('msgProducto', '❌ No se pudo guardar el producto', 'err');
        }
    } catch (e) { mostrarMsg('msgProducto', '❌ Error de conexión con el servidor', 'err'); }
}

// ════════════════════════════════════════════════════════════════════════
// OFERTANTE: Cargar mis productos
// ════════════════════════════════════════════════════════════════════════
async function cargarMisProductos() {
    const cont = document.getElementById('listaOfertante');
    if (!cont) return;
    cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">Cargando...</p>';

    try {
        const ofId = usuarioActual ? usuarioActual.id : 0;
        const res = await fetch(API_PRODS + '/productos?ofertanteId=' + ofId);
        const text = await res.text();
        let list;
        try { list = JSON.parse(text); } catch { list = []; }

        if (!list.length) {
            cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">No tienes productos registrados aún.</p>';
            return;
        }
        cont.innerHTML = list.map(prodCardOfertante).join('');
    } catch (e) {
        cont.innerHTML = '<p style="color:var(--danger);font-size:.88rem">❌ Error al conectar con el servidor.</p>';
    }
}

function prodCardOfertante(p) {
    const data = JSON.stringify(p).replace(/"/g, '&quot;');
    return `
    <div class="prod-card ${p.estado}">
        <div class="prod-titulo">${p.titulo}</div>
        <div>${badgeEstado(p.estado)}</div>
        <div class="prod-desc">${p.descripcion}</div>
        <div class="prod-meta">
            <span class="prod-precio">Bs. ${parseFloat(p.precio).toFixed(2)}</span>
            <span class="badge b-info">${p.categoria}</span>
        </div>
        ${p.motivoRechazo ? `<div class="motivo">🚫 ${p.motivoRechazo}</div>` : ''}
        <div class="prod-actions">
            <button class="btn-warning btn-sm" onclick='cargarEdicion(${data})'>✏️ Editar</button>
            <button class="btn-danger  btn-sm" onclick="eliminarProducto(${p.id})">🗑️ Eliminar</button>
        </div>
    </div>`;
}

function cargarEdicion(p) {
    document.getElementById('prodEditId').value    = p.id;
    document.getElementById('prodTitulo').value    = p.titulo;
    document.getElementById('prodDesc').value      = p.descripcion;
    document.getElementById('prodPrecio').value    = p.precio;
    document.getElementById('prodCategoria').value = p.categoria;
    document.getElementById('prodTipo').value      = p.tipo || 'PRODUCTO';
    document.getElementById('prodFormTitulo').innerHTML = `✏️ Editando: "${p.titulo}"`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function cancelarEdicion() {
    document.getElementById('prodEditId').value = '';
    ['prodTitulo','prodDesc','prodPrecio'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('prodCategoria').value = '';
    document.getElementById('prodTipo').value = 'PRODUCTO';
    document.getElementById('prodFormTitulo').textContent = '➕ Registrar Producto/Servicio';
}

async function eliminarProducto(id) {
    if (!confirm('¿Eliminar este producto?')) return;
    try {
        const res = await fetch(API_PRODS + '/productos?id=' + id, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
            mostrarMsg('msgProducto', '✅ Producto eliminado correctamente', 'ok');
            cargarMisProductos();
        }
    } catch (e) { mostrarMsg('msgProducto', '❌ Error al eliminar', 'err'); }
}

// ════════════════════════════════════════════════════════════════════════
// OFERTANTE: Solicitudes recibidas
// ════════════════════════════════════════════════════════════════════════
async function cargarSolicitudesOfertante() {
    const cont = document.getElementById('listaSolicitudesRecibidas');
    if (!cont) return;

    const ofId = usuarioActual ? usuarioActual.id : 0;
    try {
        const res = await fetch(API_PRODS + '/solicitudes?ofertanteId=' + ofId);
        const text = await res.text();
        let lista;
        try { lista = JSON.parse(text); } catch { lista = []; }

        if (!lista.length) {
            cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">No tienes solicitudes pendientes de clientes.</p>';
            return;
        }
        cont.innerHTML = lista.map(s => `
            <div class="prod-card ${s.estado}" style="border-left:4px solid ${colorEstadoSol(s.estado)}">
                <div style="display:flex;justify-content:space-between;">
                    <span class="prod-titulo">📦 ${s.productoTitulo || 'Producto'}</span>
                    <span class="badge b-info">${s.fecha || ''}</span>
                </div>
                <div style="font-size:.85rem"><strong>Cliente:</strong> ${s.demandanteNombre || '–'}</div>
                <div class="prod-desc" style="background:rgba(0,0,0,.03);padding:8px;border-radius:4px;font-style:italic">
                    "${s.notas || ''}"
                </div>
                <div style="font-size:.8rem"><strong>Estado:</strong> <span style="color:${colorEstadoSol(s.estado)};font-weight:700">${s.estado}</span></div>
                ${s.estado === 'PENDIENTE' ? `
                <div class="prod-actions">
                    <button class="btn-success btn-sm" style="flex:1" onclick="responderSolicitud(${s.id},'ACEPTADA')">✅ Aceptar</button>
                    <button class="btn-danger btn-sm" style="flex:1" onclick="responderSolicitud(${s.id},'RECHAZADA')">❌ Rechazar</button>
                </div>` : ''}
            </div>`).join('');
    } catch (e) {
        cont.innerHTML = '<p style="color:var(--danger);font-size:.88rem">❌ Error al cargar solicitudes.</p>';
    }
}

async function responderSolicitud(id, estado) {
    try {
        const res = await fetch(API_PRODS + '/solicitudes', {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, estado })
        });
        const data = await res.json();
        if (data.success) { alert('✅ Solicitud actualizada: ' + estado); cargarSolicitudesOfertante(); }
    } catch (e) { alert('❌ Error al responder solicitud'); }
}

// ════════════════════════════════════════════════════════════════════════
// ADMIN: Panel de validación
// ════════════════════════════════════════════════════════════════════════
async function cargarAdmin() {
    const cont = document.getElementById('listaAdmin');
    if (!cont) return;
    cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">Cargando...</p>';

    try {
        const res = await fetch(API_PRODS + '/productos?estado=PENDIENTE');
        const text = await res.text();
        let pendientes;
        try { pendientes = JSON.parse(text); } catch { pendientes = []; }

        // Cargar stats (todos los productos)
        const resAll = await fetch(API_PRODS + '/productos?orden=recientes&_todos=1');
        // Solo para stats: contamos de todos
        cargarStats();

        if (!pendientes.length) {
            cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">✅ No hay productos pendientes.</p>';
            return;
        }
        cont.innerHTML = pendientes.map(prodCardAdmin).join('');
    } catch (e) {
        cont.innerHTML = '<p style="color:var(--danger)">❌ Error al cargar pendientes.</p>';
    }
}

async function cargarStats() {
    try {
        // Pedir pendientes, aprobados, rechazados
        const [resPend, resApr, resRech] = await Promise.all([
            fetch(API_PRODS + '/productos?estado=PENDIENTE'),
            fetch(API_PRODS + '/productos?orden=recientes'),
            fetch(API_PRODS + '/productos?estado=PENDIENTE') // Reutilizamos lo que tenemos
        ]);
        const pend = await safeJson(resPend);
        const apr  = await safeJson(resApr);
        if (document.getElementById('cntPend')) document.getElementById('cntPend').textContent = pend.length || 0;
        if (document.getElementById('cntApr'))  document.getElementById('cntApr').textContent  = apr.length  || 0;
        if (document.getElementById('cntRech')) document.getElementById('cntRech').textContent = '–';
    } catch(e) {}
}

async function safeJson(res) {
    const text = await res.text();
    try { return JSON.parse(text); } catch { return []; }
}

function prodCardAdmin(p) {
    return `
    <div class="prod-card ${p.estado}">
        <div class="prod-titulo">${p.titulo}</div>
        <div class="prod-desc">${p.descripcion}</div>
        <div class="prod-meta">
            <span class="prod-precio">Bs. ${parseFloat(p.precio).toFixed(2)}</span>
            <span class="badge b-info">${p.categoria}</span>
        </div>
        <div style="font-size:.78rem;color:var(--muted)">👤 ${p.ofertanteNombre || 'Ofertante'} · ${p.tipo || 'PRODUCTO'}</div>
        <div class="prod-actions">
            <button class="btn-success btn-sm" onclick="aprobar(${p.id})">✅ Aprobar</button>
            <button class="btn-danger  btn-sm" onclick="abrirModalRechazo(${p.id})">❌ Rechazar</button>
        </div>
    </div>`;
}

async function aprobar(id) {
    try {
        const res = await fetch(API_PRODS + '/productos', {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, decision: 'APROBADO' })
        });
        const data = await res.json();
        if (data.success) { alert('✅ Producto aprobado.'); cargarAdmin(); }
    } catch (e) { alert('❌ Error al aprobar'); }
}

function abrirModalRechazo(id) {
    productoARechazar = id;
    document.getElementById('motivoTexto').value = '';
    document.getElementById('overlayRechazo').classList.add('open');
}

async function confirmarRechazo() {
    const motivo = document.getElementById('motivoTexto').value.trim();
    if (!motivo) { alert('Debes escribir el motivo del rechazo.'); return; }
    try {
        const res = await fetch(API_PRODS + '/productos', {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: productoARechazar, decision: 'RECHAZADO', motivoRechazo: motivo })
        });
        const data = await res.json();
        if (data.success) { alert('❌ Producto rechazado.'); cerrarModalRechazo(); cargarAdmin(); }
    } catch (e) { alert('❌ Error al rechazar'); }
}

function cerrarModalRechazo() {
    document.getElementById('overlayRechazo').classList.remove('open');
    productoARechazar = null;
}

// ════════════════════════════════════════════════════════════════════════
// DEMANDANTE: Catálogo
// ════════════════════════════════════════════════════════════════════════
async function cargarCatalogo() {
    await cargarCatalogoEn('listaCatalogo');
}

async function cargarCatalogoEn(contId) {
    const cont = document.getElementById(contId);
    if (!cont) return;
    cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">Cargando catálogo...</p>';

    try {
        const res = await fetch(API_PRODS + '/productos?orden=recientes');
        const text = await res.text();
        try { catalogoCache = JSON.parse(text); } catch { catalogoCache = []; }
        filtrarCatalogo(contId);
    } catch (e) {
        cont.innerHTML = '<p style="color:var(--danger)">❌ Error al cargar el catálogo.</p>';
    }
}

function filtrarCatalogo(contId) {
    const buscarEl   = document.getElementById('buscar');
    const filtroCat  = document.getElementById('filtroCat');
    const ordenarCat = document.getElementById('ordenarCat');
    const txt   = buscarEl   ? buscarEl.value.toLowerCase()   : '';
    const cat   = filtroCat  ? filtroCat.value                : '';
    const orden = ordenarCat ? ordenarCat.value               : 'recientes';

    let filtrados = catalogoCache.filter(p =>
        (p.titulo.toLowerCase().includes(txt) || p.descripcion.toLowerCase().includes(txt)) &&
        (!cat || p.categoria === cat)
    );

    if (orden === 'recientes')    filtrados.sort((a, b) => b.id - a.id);
    else if (orden === 'calificados') filtrados.sort((a, b) => (b.calificacion || 0) - (a.calificacion || 0));
    else if (orden === 'utilizados')  filtrados.sort((a, b) => (b.contadorSolicitudes || 0) - (a.contadorSolicitudes || 0));

    const target = contId || 'listaCatalogo';
    const cont = document.getElementById(target);
    if (!cont) return;

    if (!filtrados.length) {
        cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">No se encontraron productos.</p>';
        return;
    }

    const esDemandante = usuarioActual && usuarioActual.rol === 'DEMANDANTE';
    cont.innerHTML = filtrados.map(p => `
        <div class="prod-card APROBADO">
            <div class="prod-titulo">${p.titulo}</div>
            <div style="display:flex;gap:.4rem;flex-wrap:wrap">
                <span class="badge b-info">${p.categoria}</span>
                <span class="badge" style="background:#fff3e0;color:#e65100">${p.tipo || 'PRODUCTO'}</span>
                ${p.calificacion > 0 ? `<span class="badge" style="background:#fef3c7;color:#92400e">⭐ ${parseFloat(p.calificacion).toFixed(1)}</span>` : ''}
                ${p.contadorSolicitudes > 0 ? `<span class="badge" style="background:#f3e8ff;color:#7e22ce">🔥 ${p.contadorSolicitudes} sol.</span>` : ''}
            </div>
            <div class="prod-desc">${p.descripcion}</div>
            <div class="prod-meta">
                <span class="prod-precio">Bs. ${parseFloat(p.precio).toFixed(2)}</span>
                <span style="font-size:.78rem;color:var(--muted)">👤 ${p.ofertanteNombre || 'Anónimo'}</span>
            </div>
            ${esDemandante ? `
            <div class="prod-actions" style="margin-top:6px">
                <button class="btn-success btn-sm" style="flex:1" onclick="abrirModalSolicitud(${p.id}, '${escHtml(p.titulo)}')">📩 Solicitar</button>
                <button class="btn-warning btn-sm" onclick="abrirModalCalificar(${p.id}, '${escHtml(p.titulo)}')">⭐ Calificar</button>
            </div>` : ''}
        </div>`).join('');
}

// ════════════════════════════════════════════════════════════════════════
// DEMANDANTE: Modal Solicitud
// ════════════════════════════════════════════════════════════════════════
function abrirModalSolicitud(id, titulo) {
    productoASolicitar = id;
    document.getElementById('modalSolicitudTitulo').textContent = '📩 Solicitar: ' + titulo;
    document.getElementById('solicitudNotas').value = '';
    document.getElementById('overlaySolicitud').classList.add('open');
}

async function confirmarSolicitud() {
    const notas = document.getElementById('solicitudNotas').value.trim();
    if (notas.length < 5) { alert('❌ Escribe una descripción de al menos 5 caracteres.'); return; }

    try {
        const res = await fetch(API_PRODS + '/solicitudes', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                productoId:   productoASolicitar,
                demandanteId: usuarioActual ? usuarioActual.id : 0,
                notas
            })
        });
        const data = await res.json();
        if (data.success) {
            alert('✅ ¡Solicitud enviada al ofertante!');
            cerrarModalSolicitud();
            cargarCatalogo();
        } else {
            alert('❌ No se pudo enviar la solicitud.');
        }
    } catch (e) { alert('❌ Error de conexión'); }
}

function cerrarModalSolicitud() {
    document.getElementById('overlaySolicitud').classList.remove('open');
    productoASolicitar = null;
}

// ════════════════════════════════════════════════════════════════════════
// DEMANDANTE: Mis Solicitudes
// ════════════════════════════════════════════════════════════════════════
async function cargarMisSolicitudes() {
    const cont = document.getElementById('listaMisSolicitudes');
    if (!cont) return;

    const demId = usuarioActual ? usuarioActual.id : 0;
    try {
        const res = await fetch(API_PRODS + '/solicitudes?demandanteId=' + demId);
        const text = await res.text();
        let lista;
        try { lista = JSON.parse(text); } catch { lista = []; }

        if (!lista.length) {
            cont.innerHTML = '<p style="color:var(--muted);font-size:.88rem">Aún no has realizado solicitudes.</p>';
            return;
        }
        cont.innerHTML = lista.map(s => `
            <div class="prod-card ${s.estado}" style="border-left:4px solid ${colorEstadoSol(s.estado)}">
                <div style="display:flex;justify-content:space-between">
                    <span class="prod-titulo">📦 ${s.productoTitulo || 'Producto'}</span>
                    <span class="badge b-info">${s.fecha || ''}</span>
                </div>
                <div class="prod-desc" style="font-style:italic">"${s.notas || ''}"</div>
                <div style="font-size:.8rem">
                    <strong>Estado:</strong>
                    <span style="color:${colorEstadoSol(s.estado)};font-weight:700">${s.estado}</span>
                </div>
                ${s.estado === 'ACEPTADA' ? `
                <div class="prod-actions">
                    <button class="btn-warning btn-sm" onclick="abrirModalCalificarSolicitud(${s.productoId}, '${escHtml(s.productoTitulo || '')}')">⭐ Calificar este servicio</button>
                </div>` : ''}
            </div>`).join('');
    } catch (e) {
        cont.innerHTML = '<p style="color:var(--danger)">❌ Error al cargar solicitudes.</p>';
    }
}

// ════════════════════════════════════════════════════════════════════════
// DEMANDANTE: Calificación
// ════════════════════════════════════════════════════════════════════════
function abrirModalCalificar(id, titulo) {
    productoACalificar = id;
    calificacionSeleccionada = 0;
    document.getElementById('calificarProductoNombre').textContent = titulo;
    document.querySelectorAll('.estrella').forEach(e => e.classList.remove('activa'));
    document.getElementById('overlayCalificar').classList.add('open');
}

function abrirModalCalificarSolicitud(productoId, titulo) {
    abrirModalCalificar(productoId, titulo);
}

function seleccionarEstrella(n) {
    calificacionSeleccionada = n;
    document.querySelectorAll('.estrella').forEach((e, i) => {
        e.classList.toggle('activa', i < n);
    });
}

async function confirmarCalificacion() {
    if (!calificacionSeleccionada) { alert('Selecciona al menos 1 estrella.'); return; }
    try {
        const res = await fetch(API_PRODS + '/calificar', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ productoId: productoACalificar, calificacion: calificacionSeleccionada })
        });
        const data = await res.json();
        if (data.success) {
            alert('✅ ¡Gracias por tu calificación!');
            cerrarModalCalificar();
            cargarCatalogo();
        } else { alert('❌ Solo se puede calificar productos aprobados.'); }
    } catch (e) { alert('❌ Error al enviar calificación'); }
}

function cerrarModalCalificar() {
    document.getElementById('overlayCalificar').classList.remove('open');
    productoACalificar = null;
    calificacionSeleccionada = 0;
}

// ════════════════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════════════════
function badgeEstado(estado) {
    const m = { PENDIENTE: 'b-pending', APROBADO: 'b-approved', RECHAZADO: 'b-rejected' };
    const i = { PENDIENTE: '⏳', APROBADO: '✅', RECHAZADO: '❌' };
    return `<span class="badge ${m[estado] || ''}">${(i[estado] || '') + ' ' + estado}</span>`;
}

function colorEstadoSol(estado) {
    return estado === 'ACEPTADA' ? '#059669' : estado === 'RECHAZADA' ? '#dc2626' : '#d97706';
}

function escHtml(str) {
    return (str || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}
